package desafio_dupla;

import java.util.Scanner;

public class codigoJava {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in); 
		String nomeProfessor, disciplina, siglaTurma, msgAlunos = "-----------------------------------"+"\nAlunos:", nome, msg = "-----------------------------------"+"\nProfessores: " ;
		int qtdAlunos = 0, qtdAvaliacoes = 0, resposta = 0;
		double nota, notas = 0.0, media = 0.0;
		
		do {
			System.out.print("Nome do professor: ");
			nomeProfessor = sc.next();
			System.out.print("\nDisciplina que o mesmo leciona: ");
			disciplina = sc.next();
			System.out.print("\nSigla da turma: ");
			siglaTurma = sc.next();
			System.out.print("\nInforme a quantidade de alunos que esta turma possui: ");
			qtdAlunos = sc.nextInt(); 
			System.out.print("\nQuantas avalia��es foram aplicadas? ");
			qtdAvaliacoes = sc.nextInt();
			msg +="\n---"+"\nProfessor: " + nomeProfessor +"\nDisciplina: " + disciplina + "\nTurma: " + siglaTurma + "\nQuantidade de alunos: "+ qtdAlunos;
			for(int rAlunos = 1; rAlunos <= qtdAlunos; rAlunos++) {
				
				System.out.println("\nInforme o nome do " + rAlunos + "� aluno: ");
				nome = sc.next();
				media = 0.0;
				notas = 0.0;
				for(int rnotas = 1; rnotas <= qtdAvaliacoes; rnotas++) {
					System.out.println("Informe a " + rnotas + "� nota: ");
					nota = sc.nextDouble();
					notas= notas + nota;
					media= notas /rnotas;
				}
				if(media >= 7) {
					msgAlunos += "---" + "\nAlunos: " + nome + "\nTurma: "+ siglaTurma+ "\nM�dia: "+ media + "\nSitua��o: Aprovado";
				}
				else if(media <7 & media >=5) {
					msgAlunos += "---" + "\nAlunos: "+ nome + "\nTurma: "+ siglaTurma+ "\nM�dia: "+ media + "\nSitua��o: Exame";
				}
				else {
					msgAlunos += "---" + "\nAlunos: " + nome + "\nTurma: "+ siglaTurma+ "\nM�dia: "+ media + "\nSitua��o: Reprovado";
				}
			}
			System.out.println("Deseja cadastrar uma nova turma? "
					+"\n1- Sim"
					+"\n2- N�o");
			resposta = sc.nextInt();
			} while (resposta == 1);
			System.out.println("\n" + msg);
			System.out.println("\n" + msgAlunos);

	}

}
