import java.util.Scanner;

public class desafioJava {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String nomeProfessor, disciplina, siglaTurma, msg = "\nProfessor: ";
		int qtdAlunos, qtdAvaliacoes;
		
		
		System.out.print("Nome do professor: ");
		nomeProfessor = sc.next();
		System.out.print("\nDisciplina que o mesmo leciona: ");
		disciplina = sc.next();
		System.out.print("\nSigla da turma: ");
		siglaTurma = sc.next();
		System.out.print("\nInforme a quantidade de alunos que esta turma possui: ");
		qtdAlunos = sc.nextInt(); 
		msg += nomeProfessor +"\nDisciplina: " + disciplina + "\nTurma: " + siglaTurma + "\nQuantidade de alunos: "+ qtdAlunos;
		System.out.print("\nQuantas avalia��es foram aplicadas? ");
		qtdAvaliacoes = sc.nextInt();
		System.out.println("\n" + msg);
	}

}
