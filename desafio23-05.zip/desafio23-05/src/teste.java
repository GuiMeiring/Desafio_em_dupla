import java.util.Scanner;

public class teste {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		int qdavaliacoes; 
		double media = 0.0, nota, notas = 0.0;
		System.out.println("Quantas avalia��es? ");
		qdavaliacoes= sc.nextInt();
		for(int rnotas = 1; rnotas <= qdavaliacoes; rnotas++) {
			System.out.println("informe a " + rnotas + "� nota: ");
			nota = sc.nextInt();
			notas = nota + notas;
		    media = notas / rnotas;
		}
		System.out.println("A m�dia �: " + media);
	}

}
