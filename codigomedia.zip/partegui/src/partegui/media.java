package partegui;

import java.util.Scanner;

public class media {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		int qtdnotas;
		double nota , notas = 0.0 , media=0.0;
		String msgalunos = "Aluno: ";
		System.out.println("Informe a quamtidade de notas: ");
		qtdnotas=sc.nextInt();
		for(int rnotas = 1; rnotas <=qtdnotas;rnotas++) {
			System.out.println("Informe a " + rnotas + "� nota: ");
			nota = sc.nextDouble();
			notas=notas + nota;
			media=notas /rnotas;
		}
		if(media >= 7) {
			msgalunos += "\nM�dia: " + media + "\nSitua��o: Aprovado";
		}
		else if(media <7 & media >=5) {
			msgalunos += "\nM�dia: " + media + "\nSitua��o: Exame";
		}
		else {
			msgalunos += "\nM�dia: " + media + "\nSitua��o: Reprovado";
		}
		System.out.println(msgalunos);

	}
}